module.exports = {
  dynamoTable: 'laa_crime_applications'
};
